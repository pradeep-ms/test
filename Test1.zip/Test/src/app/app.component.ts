import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Saving Account';

  registrationForm: FormGroup;

  ngOnInit(): void {
    this.registrationForm = new FormGroup({
      'personalDetails': new FormGroup({
        'firstname': new FormControl(null),
        'lastname': new FormControl(null),
      }),
      'Amount Details': new FormGroup({
        'Amount': new FormControl(null),
        'IBAN': new FormControl(null)
      })
    });

  }

}
